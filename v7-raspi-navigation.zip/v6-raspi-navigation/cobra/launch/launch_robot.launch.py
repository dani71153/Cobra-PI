#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, RegisterEventHandler, TimerAction
from launch.event_handlers import OnProcessExit, OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import Command

def generate_launch_description():
    # Nombre del paquete
    package_name = 'cobra'

    # Obtener el directorio del paquete
    package_share_directory = get_package_share_directory(package_name)
    xacro_file = os.path.join(package_share_directory, 'description', 'robot_core.xacro')

    # Convertir Xacro a URDF
    robot_description = Command(['xacro ', xacro_file])

    # Incluir el archivo de lanzamiento de robot_state_publisher
    rsp = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory(package_name), 'launch', 'rsp.launch.py')
        ]),
        launch_arguments={'use_sim_time': 'false', 'use_ros2_control':'true'}.items()
    )

    robot_description = Command(['ros2 param get --hide-type /robot_state_publisher robot_description'])
    controller_params_file = os.path.join(get_package_share_directory(package_name),'config','my_controllers.yaml')

    controller_manager = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[{'robot_description': robot_description},
                    controller_params_file]
    )

    delayed_controller_manager = TimerAction(period=5.0, actions=[controller_manager])

    # Spawner para el controlador de manejo diferencial
    diff_drive_spawner = Node(
        package="controller_manager",
        executable="spawner.py",
        arguments=["diff_cont"]
    )

    delayed_diff_drive_spawner = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=controller_manager,
            on_start=[diff_drive_spawner],
        )
    )

    # Spawner para el publicador de estados de las articulaciones
    joint_broad_spawner = Node(
        package="controller_manager",
        executable="spawner.py",
        arguments=["joint_broad"]
    )

    delayed_joint_broad_spawner = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=controller_manager,
            on_start=[joint_broad_spawner],
        )
    )

    # Nodo para la transformación estática entre odom y base_link
    static_transform_publisher_odom_to_base_link = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_link'],
        output='screen'
    )

    # Nodo para la transformación estática entre base_link y laser_frame
    static_transform_publisher_base_link_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0.15', '0', '0', '0', 'base_link', 'laser_frame'],
        output='screen'
    )

    # Nodo para la transformación estática entre odom y laser_frame
    static_transform_publisher_odom_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0.15', '0', '0', '0', 'odom', 'laser_frame'],
        output='screen'
    )

    # Nodo para la transformación estática entre laser_frame y odom
    static_transform_publisher_laser_to_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '-0.15', '0', '0', '0', 'laser_frame', 'odom'],
        output='screen'
    )

    # Lanzar los nodos en el orden correcto
    #return LaunchDescription([
    #    rsp,
    #    gazebo,
    #    spawn_entity,
    #    controller_manager_node,
    #    RegisterEventHandler(
    #        OnProcessExit(
    #            target_action=spawn_entity,
    #            on_exit=[joint_broad_spawner, diff_drive_spawner],
    #        )
    #    )
    #])

    return LaunchDescription([
        rsp,
        delayed_controller_manager,
        delayed_diff_drive_spawner,
        delayed_joint_broad_spawner,
        TimerAction(
            period=2.0,  # Espera 2 segundos para que los nodos estén completamente listos
            actions=[
                static_transform_publisher_odom_to_base_link,
                static_transform_publisher_base_link_to_laser,
                static_transform_publisher_odom_to_laser,
                static_transform_publisher_laser_to_odom,
            ]
        ),
    ])