#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import pygame
import time

class KeyboardTeleop(Node):
    def __init__(self):
        super().__init__('keyboard_teleop')
        self.publisher_ = self.create_publisher(Twist, '/diff_cont/cmd_vel_unstamped', 10)
        self.velocity = 1.5  # velocidad lineal
        self.angular_velocity = 1.5  # velocidad angular

        pygame.init()
        pygame.display.set_mode((100, 100))
        self.get_logger().info('Keyboard Teleop Inicializado')

        self.linear_velocity = 0.0
        self.angular_velocity_z = 0.0

    def run(self):
        try:
            while rclpy.ok():
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_UP:
                            self.linear_velocity = self.velocity
                        elif event.key == pygame.K_DOWN:
                            self.linear_velocity = -self.velocity
                        elif event.key == pygame.K_LEFT:
                            self.angular_velocity_z = self.angular_velocity
                        elif event.key == pygame.K_RIGHT:
                            self.angular_velocity_z = -self.angular_velocity
                    elif event.type == pygame.KEYUP:
                        if event.key in [pygame.K_UP, pygame.K_DOWN]:
                            self.linear_velocity = 0.0
                        elif event.key in [pygame.K_LEFT, pygame.K_RIGHT]:
                            self.angular_velocity_z = 0.0

                self.publish_velocity(self.linear_velocity, self.angular_velocity_z)
                rclpy.spin_once(self, timeout_sec=0.1)
                time.sleep(0.01)
        except KeyboardInterrupt:
            pass

    def publish_velocity(self, linear, angular):
        msg = Twist()
        msg.linear.x = linear
        msg.angular.z = angular
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: linear={linear} angular={angular}')

def main(args=None):
    rclpy.init(args=args)
    node = KeyboardTeleop()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
