#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, RegisterEventHandler, TimerAction
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import Command

def generate_launch_description():
    # Nombre del paquete
    package_name = 'cobra'

    # Obtener el directorio del paquete
    package_share_directory = get_package_share_directory(package_name)
    xacro_file = os.path.join(package_share_directory, 'description', 'robot_core.xacro')

    # Convertir Xacro a URDF
    robot_description = Command(['xacro ', xacro_file])

    # Incluir el archivo de lanzamiento de robot_state_publisher
    rsp = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(package_share_directory, 'launch', 'rsp.launch.py')
        ]),
        launch_arguments={'use_sim_time': 'true'}.items()
    )

    # Incluir el archivo de lanzamiento de Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ]),
        launch_arguments={'use_sim_time': 'true'}.items()
    )

    # Generar la entidad del robot en Gazebo
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'cobra'],
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    # Inicializar el nodo del controlador
    controller_manager_node = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[{'robot_description': robot_description, 'use_sim_time': True}],
        output='screen'
    )

    # Spawner para el controlador de manejo diferencial
    diff_drive_spawner = Node(
        package="controller_manager",
        executable="spawner.py",
        arguments=["diff_cont"],
        parameters=[{'use_sim_time': True}]
    )

    # Spawner para el publicador de estados de las articulaciones
    joint_broad_spawner = Node(
        package="controller_manager",
        executable="spawner.py",
        arguments=["joint_broad"],
        parameters=[{'use_sim_time': True}]
        )


    # Nodo para SLAM Toolbox
    slam_toolbox = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory('slam_toolbox'), 'launch', 'online_async_launch.py')
        ]),
        launch_arguments={
            'params_file': os.path.join(package_share_directory, 'config', 'mapper_params_online_async.yaml'),
            'use_sim_time': 'true'
        }.items()
    )

    # Lanzar los nodos en el orden correcto
    return LaunchDescription([
        rsp,
        gazebo,
        spawn_entity,
        controller_manager_node,
        RegisterEventHandler(
            OnProcessExit(
                target_action=spawn_entity,
                on_exit=[joint_broad_spawner, diff_drive_spawner],
            )
        ),
        TimerAction(
            period=3.0,  # Espera 2 segundos para que los nodos estén completamente listos
            actions=[
          #    slam_toolbox,
            ]
        )
    ])
