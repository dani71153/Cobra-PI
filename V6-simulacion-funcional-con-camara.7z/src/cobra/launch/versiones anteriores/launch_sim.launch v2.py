#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.actions import EmitEvent
from launch.events import Shutdown

def generate_launch_description():
    package_name = 'cobra'
    pkg_path = get_package_share_directory(package_name)

    
    # Leer el contenido del archivo URDF
    urdf_file_path = os.path.join(pkg_path, 'description', 'robot_core(v3).urdf')
    with open(urdf_file_path, 'r') as file:
        robot_description = file.read()

    # Nodo robot_state_publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='both',
        parameters=[{'robot_description': robot_description}]
    )

    # Incluir el archivo de lanzamiento de Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ]),
    )

    # Node para spawn_entity con retardo
    spawn_entity = TimerAction(
        period=5.0,  # Espera 5 segundos antes de intentar spawn_entity
        actions=[
            Node(
                package='gazebo_ros',
                executable='spawn_entity.py',
                arguments=['-topic', 'robot_description', '-entity', 'cobra'],
                output='screen'
            )
        ]
    )

    controller_params_file = os.path.join(get_package_share_directory(package_name),'config','my_controllers.yaml')

    controller_manager = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[{'robot_description': robot_description},
                    controller_params_file]
    )

    delayed_controller_manager = TimerAction(period=3.0, actions=[controller_manager])
    # Spawner para el controlador de manejo diferencial
    diff_drive_spawner = Node(
        package="controller_manager",
        executable="spawner.py",
        arguments=["diff_cont"]
    )

    # Spawner para el publicador de estados de las articulaciones
    joint_broad_spawner = Node(
        package="controller_manager",
        executable="spawner.py",
        arguments=["joint_broad"]
    )

    # Lanzar los nodos en el orden correcto
    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true', description='Use simulation (Gazebo) clock if true'),
        robot_state_publisher,
        gazebo,
        spawn_entity,
        controller_manager,
        diff_drive_spawner,
        joint_broad_spawner
    ])





