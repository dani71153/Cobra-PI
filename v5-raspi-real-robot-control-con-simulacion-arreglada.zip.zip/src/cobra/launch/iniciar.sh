#!/bin/bash

# Asegúrate de estar en el entorno correcto, ajusta según sea necesario
source /opt/ros/foxy/setup.bash
source ~/ros2_ws/install/setup.bash

# Directorio de tu paquete
PACKAGE_DIR=$(ros2 pkg prefix cobra)

# Lanzar robot_state_publisher
ros2 launch $PACKAGE_DIR/launch/rsp.launch.py use_sim_time:=true use_ros2_control:=true &

# Espera para asegurar que rsp se ha iniciado
sleep 5

# Lanzar Gazebo
ros2 launch gazebo_ros gazebo.launch.py &

# Espera para asegurar que Gazebo se ha iniciado
sleep 10

# Spawn del modelo del robot en Gazebo
ros2 run gazebo_ros spawn_entity.py -topic robot_description -entity cobra &

# Espera para asegurar que el modelo del robot se ha cargado
sleep 5

# Iniciar el nodo de controller_manager
ros2 run controller_manager ros2_control_node &

# Espera para asegurar que el nodo de control se ha iniciado
sleep 5

# Spawner para el controlador de manejo diferencial
ros2 run controller_manager spawner.py diff_cont &

# Spawner para el publicador de estados de las articulaciones
ros2 run controller_manager spawner.py joint_broad &

wait
