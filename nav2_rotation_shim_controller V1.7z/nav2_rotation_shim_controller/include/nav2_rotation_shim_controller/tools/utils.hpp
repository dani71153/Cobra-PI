// Copyright (c) 2022 Samsung Research America, @artofnothingness Alexey Budyakov
// Copyright (c) 2023 Open Navigation LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#ifndef NAV2_ROTATION_SHIM_CONTROLLER__TOOLS__UTILS_HPP_
#define NAV2_ROTATION_SHIM_CONTROLLER__TOOLS__UTILS_HPP_

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "rclcpp/rclcpp.hpp"

namespace nav2_rotation_shim_controller::utils
{

/**
* @brief Check if the robot is within the position goal tolerance
* @param robot The current pose of the robot
* @param goal The goal pose to check against
* @return bool Whether the robot is within the distance tolerance ignoring rotation and speed
*/
inline bool withinPositionGoalTolerance(
  const geometry_msgs::msg::Pose & robot,
  const geometry_msgs::msg::Pose & goal,
  double pose_tolerance_x = 0.1,  // Default tolerance value for x
  double pose_tolerance_y = 0.1)  // Default tolerance value for y
{
  // Calculate the difference in positions
  auto dx = robot.position.x - goal.position.x;
  auto dy = robot.position.y - goal.position.y;

  // Calculate the squared distance
  auto dist_sq = dx * dx + dy * dy;

  // Check if the squared distance is within the squared tolerance
  return dist_sq < (pose_tolerance_x * pose_tolerance_x + pose_tolerance_y * pose_tolerance_y);
}

}  // namespace nav2_rotation_shim_controller::utils

#endif  // NAV2_ROTATION_SHIM_CONTROLLER__TOOLS__UTILS_HPP_
